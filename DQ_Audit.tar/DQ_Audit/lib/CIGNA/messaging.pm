package CIGNA::messaging;
# -------------------------------------------------------------------------------------------
# Name: Rajesh Acharya
# Module: messaging
# 
# Methods available:
#    new			Constructor for the object
#    write_MsgQ			put a message into the message file 
#				  in the message dir
#    write_ToMailPRG		write message directly to the mail program
#    write_to_logfile		write message to the notifier.log file
#    write_to_sntmsgslog	write message to sent messages log 
#				  file (sentmessgs)
#    create_logmsg		create the message for writing to log file
#    create_sntlog		create the message for writing to the 
#				  sentmessgs log file
#    check_filesize		check the size of any file against the 
#				  actual approx size
#    check_logfilesize		for log rolling and backup
#    check_dirs			create the log directory if it doesn't exists

use File::Basename;
require Exporter;

our @ISA = qw(Exporter);

our $VERSION = '0.05';

sub new
{
  my $class = shift;
  my $self = bless { 
			'srvrname'	=> '',
		        'defsep'	=> ':',
			'configfl'	=> @_
		   }, $class;

  if ($self->{'configfl'} eq "")
    {
	my  $rtpth="/export/home/intadmin/DQ_Audit";
	$self->{'configfl'} = $rtpth . "/config/notifier.conf";
    }

  $self->{'srvrname'} = `/usr/bin/hostname`;
  chomp($self->{'srvrname'});

  # call the local sub to read in config file
  &config_init($self,$self->{'configfl'});

  if ($self->{'addtl_msgs'})
    {
       $self->{'defsep'} = $self->{'addtl_fsep'};

       # call the local sub to read additional info
       &config_init($self,$self->{'addtl_msgs'});
    }

  # define remaining path infos
  $self->{'msgfpth'} = "$self->{'msgdir'}/$self->{'msgfile'}";
  $self->{'shutdown'} = "$self->{'msgdir'}/notifier.shutdown";
  $self->{'startup'} = "$self->{'msgdir'}/notifier.started";
  $self->{'logdir'}  = "$self->{'msgdir'}/logs";
  $self->{'logfile'} = "$self->{'logdir'}/notifier$this->{'logflext'}";
  $self->{'sntmsgs'} = "$self->{'logdir'}/sentmessgs$this->{'sntlgext'}";
  $self->{'logfbak'} = "$self->{'logdir'}/notifier$this->{'logflbak'}";
  $self->{'sntfbak'} = "$self->{'logdir'}/sentmessgs$this->{'logflbak'}";

  return($self);
}

#-----------------------------------------------------------------------------
# SUB: config_init
# PURPOSE: read the main configuration information from a general configuration
#          file.
sub config_init {
  my (	$cfgstrc,			# the hash
	$cfgfile)=@_;			# config file to read

  open(CONFIGFL, "$cfgfile") || die("ERROR: Could not open config file <$cfgfile>!\n\n");
  my ($key, $val, $mail_ids);
  my ($separator);

  if ($cfgstrc->{'defsep'} =~ /:/)
    {
	$separator=$cfgstrc->{'defsep'};
    }
  else
    {
	$separator=quotemeta($cfgstrc->{'defsep'});
    }	
      
  $mail_ids=0;
  while(<CONFIGFL>) {
    chomp;
    s/\s+$//; # no trailing white
    next if /^\s*#/;
    next if /^\s*$/;
    ($key, $val) = split(/$separator/);

    # if mail id key begins with std or emr
    if (($key =~ /^std_/i) || ($key =~ /^emr_/i) || ($key =~ /^msg/i))
      {
        # increment mail id counter
        $mail_ids++ if (($key =~ /^std_/i) || ($key =~ /^emr_/i));    
        $cfgstrc->{lc($key)} = $val;  # store value in hash
      }
    else
      {
	$cfgstrc->{lc($key)} = $val; # store the value in hash
      }
  } # end WHILE loop
  close(CONFIGFL);
} # end subroutine


sub startup
{
  my $self = shift;

  open(STARTD,">$self->{'startup'}") ||
	die("ERROR: Could not startup the notifier services\n\n");
  close(STARTD);

  $self->write_to_logfile("Notifier Service started");
} # end sub

  
sub shutdown
{ # start sub
  my $self = shift;
  
  open(SHUTD,">$self->{'shutdown'}") ||
	die("ERROR: Could not shutdown the notifier services\n\n");
  close(SHUTD);

  print "\nNotifier shutdown complete!!\n\n";
} # end sub


sub cleanup
{
  my $self = shift;
  
  if (-f $self->{'shutdown'})
    {
       unlink($self->{'shutdown'});
    }
  if (-f $self->{'startup'})
    {
       unlink($self->{'startup'});
    }
} # end sub


sub write_MsgQ
{ # start sub
  my $self = shift;
  my ($mail_to, $subj, $messg, $msgfooter) = @_;
  my ($msgfile) = $self->{'msgdir'} . "/" . $self->{'msgfile'};

  return if ($self->{'msgactv'} == 0);
  my (@msglines) = split(/\n/, $messg);
  $messg=join("&&", @msglines);

  open(MSGQUEUE,">>$msgfile") || die("Could not create/open file for writing the message!\n\n");
  print MSGQUEUE "$mail_to|$subj|$messg|$msgfooter\n";
  close(MSGQUEUE);
} # end sub


sub check_filesize
{ # start sub
  my $self = shift;
  my ($filetocheck,$approxsize) = @_;

  if (-f $filetocheck)
    {
        my($currdir)=`pwd`;
        chomp($currdir);

        my($filebase)=dirname($filetocheck);
        chdir($filebase);
        my (@statfields) = stat(basename($filetocheck));
        chdir($currdir);

        if ($statfields[7] < $approxsize)
          {
	     return(-1);  # file size less than required size
          } # end file size check
	else
	  {
	     return 0;
	  }
    } # end IF logfile exists
  else
    {
      return(-2);  # file is missing
    }
} # end sub


sub check_logfilesizes
{ # start sub
  my $self = shift;

  if (-f $self->{'logfile'})
    {
        # check file size and move file to backup if necessary
        my($currdir)=`pwd`;
        chomp($currdir);
        chdir($self->{'logdir'});
        my (@statfields) = stat(basename($self->{'logfile'}));
        chdir($currdir);

        if ($statfields[7] >= $self->{'logflsiz'})
          {
             my (@syscmd)=("mv", "$self->{'logfile'}", "$self->{'logfbak'}");
             system(@syscmd) == 0
                      or die "ERROR: Failed to run system command";
          } # end file size check
    } # end IF logfile exists

  if (-f $self->{'sntmsgs'})
    {
        # check file size and move file to backup if necessary
        my($currdir)=`pwd`;
        chomp($currdir);
        chdir($self->{'sntmsgs'});
        my (@statfields) = stat($self->{'sntmsgs'});
        chdir($currdir);

        if ($statfields[7] >= $self->{'logflsiz'})
          {
             my (@syscmd)=("mv", "$self->{'sntmsgs'}", "$self->{'sntfbak'}");
             system(@syscmd) == 0
                      or die "ERROR: Failed to run system command";
          } # end file size check
    } # end IF logfile exists
} # end sub


sub check_dirs {
  my $self = shift;

  unless (-d "$self->{'logdir'}") {
    mkdir("$self->{'logdir'}") ||
      die("Failed to create Log Directory $self->{'logdir'}: $!\n");

    chmod(0777,$self->{'logdir'});
  }
} # end subroutine


sub write_ToMailPRG
{ # start sub
     my $self = shift;		# object
     my ($recipients,		# recepients
         $subject,		# message subject
         $mailtext,		# message text
         $mailfooter) = @_;	# message footer is any

     return if ($self->{'srvrname'} !~ /$self->{'mailsrv'}/i);

     open (MAIL, "|$self->{'mailprg'} -t") ||
        die("\nERROR: Was unable to access the mail " .
		            "utility <$self->{'mailprg'}>!\n\n");

     print MAIL "To: $recipients\n";
     print MAIL "Subject: $subject\n\n";
     print MAIL "$mailtext\n";
     print MAIL "$mailfooter\n";
     close(MAIL);
} # end sub


sub get_waitTime
{  # start sub
   my $self = shift;
   my $temp;

   my (@tmparay) = split(/\s/, $self->{'mesgchck'});
   if ($self->{'mesgchck'} =~ /min/i)
     {
        $temp=($tmparay[0] * 60);
     }
   else
     {
        $temp=$tmparay[0];
     }
   undef(@tmparay);
   return($temp);
} # end sub


sub write_to_logfile
{ # start sub
	my $self = shift;
        my ($messg) = @_;

	open (NOTIFLOG, ">>$self->{'logfile'}") ||
        	die("\nERROR: Could not open log file <$self->{'logfile'}>!\n\n");
	chmod(0777,$self->{'logfile'});
	NOTIFLOG->autoflush(1);
        print NOTIFLOG localtime() . ": $messg\n";
	close(NOTIFLOG);
} # end sub


sub write_to_sntmsgslog
{ # start sub
	my $self = shift;
        my ($messg) = @_;

	open (SNTMSGS, ">>$self->{'sntmsgs'}") ||
        	die("\nERROR: Could not open sent messages " .
				"log file <$self->{'sntmsgs'}>!\n\n");
	chmod(0777,$self->{'sntmsgs'});
	SNTMSGS->autoflush(1);
        print SNTMSGS "------- [" . localtime() . "] --------------------\n";
        print SNTMSGS "$messg\n";
        print SNTMSGS "--------------------------------------------------\n";
	close(SNTMSGS);
} # end sub


sub create_logmsg
{ # start sub
    my $self = shift;
    my ($recep,$subj) = @_;
    my ($msgstr);

    $msgstr = "Message sent to: $recep\nSubject: $subj\n";
    return($msgstr);
} # end sub


sub create_sntlog
{ # start sub
    my $self = shift;
    my ($recep, $subj, $messg, $footer) = @_;
    my ($msgstr);

    $msgstr = "To: $recep\nSubject: $subj\nMessage Block:\n$messg$footer";
    return($msgstr);
} # end sub

1;
