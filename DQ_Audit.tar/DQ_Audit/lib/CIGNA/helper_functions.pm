##############################################################################
#
# Name: Rajesh Acharya
# Module: config
# Purpose:has various functions that are standard and used regularly
#
# Functions:
#	alert_kill		sets the STOP to 1 if system signal is received
#	get_datestring		returns the current date and in format YYYYmmddHHMMSS
#	get_unix		get date-time in unix format 
#       process_messg           replaces tokens in a string with actual required values 
#				specified as comma-sep values
#
################################################################################
package CIGNA::helper_functions;

use strict;
use lib "/export/home/intadmin/DQ_Audit/lib";
use FileHandle;
require Exporter;

our @ISA = qw(Exporter);

our $SEQNUM		= 0;
our $STOP		= 0;

our @EXPORT = qw(	$SEQNUM 
			$STOP
			alert_kill
			get_datestring
			get_unix
			prog_usage
			moveFile
			check_dups
			read_cache
			getCustomer
			determineLayout
			process_messg
		);
our $VERSION = '1.00';


sub alert_kill
{  # begin sub
        $STOP=1
}  # end sub


sub read_cache
{
  my ($cfgHash) = @_;                   # get the config hash
  my ($line_0);
  my ($rec_count) = 0;                  # record count from file
  my (@filelines) = ();                 # emply array

  my ($cacheFile) = "$cfgHash->{'CACHEDIR'}/$cfgHash->{'CACHEFL'}";
  unless (-f "$cacheFile")              # check if a cache file exists
    {
        return;                         # return if not found
    }

   open(INF, '<', "$cacheFile");
   @filelines = <INF>;                  # load the array
   close(INF);                          # close file

   #clean the end of line
   foreach (@filelines)
     {
        chomp;                          # remove end of line and store back
     }

   # get the record count info
   ($rec_count,$line_0)=split(/\|/,$filelines[0]);
   $filelines[0] = $line_0;

   unlink($cacheFile);                  # remove cache file
   $cfgHash->{'RESUME'} = 1;
   $cfgHash->{'RECCOUNT'} = $rec_count; # last record processed for top file
   return(@filelines);
} # end sub


sub check_dups
{
    my ($tmparay,               # array of files
        $origList) = @_;        # orig list of files
    my (@diffaray);             # array to store any additional
    my (%tmphash);              # hash of names from tmparay

    # create a hash from files in tmparay
    foreach my $file (@$tmparay)
      {
        if (!exists($tmphash{$file}))   # add if not in hash
          {
             $tmphash{$file} = $file;
          }
      } # end loop

    # walk the main files list and compare with hash values
    foreach my $file (@$origList)
      {
         if (exists($tmphash{$file}))   # if name found in hash
           {
              push(@diffaray, $file);   # push the name onto the diff aray
              delete($tmphash{$file});   # remove from hash
           }
      } # end for-loop

    # add remaining hash entries to @diffaray
    foreach my $file (keys %tmphash)
      {
        push(@diffaray, $file);         # push name to the aray
      } # end for-loop

    @$origList = @diffaray;             # return diffaray
} # end sub


sub get_datestring {
  my($secs,$mins,$hours,$day,$month,$year,$now);
  ##
  ##  Get the log datestring for today.
  ##
  ($secs,$mins,$hours,$day,$month,$year) = (localtime)[0,1,2,3,4,5];
  $year += 1900;
  $month++;
  $day   = "0" . $day if length($day) < 2;
  $month = "0" . $month if length($month) < 2;
  $secs  = "0" . $secs if length($secs) < 2;
  $mins  = "0" . $mins if length($mins) < 2;
  $hours = "0" . $hours if length($hours) < 2;
  $now = "$year$month$day$hours$mins$secs";
  sleep(1);
  return($now);
} # end sub


sub get_unix {
  my($time,$year,$mon,$mday,$hours,$min,$sec);
  my($date) = @_;
  return(time()) unless $date;
  ## 20040111115259Z
  ($year,$mon,$mday,$hours,$min,$sec) = unpack("a4a2a2a2a2a2",$date);
  $mon--;
  ## This is run daily, so I just figure out the day.
  $time = timelocal("01","00","00",$mday,$mon,$year);
  return($time);
}


sub process_messg
{ # start sub
  my ($msgtext)=@_;
  my ($mainmsg,$replacearg_list);
  my (@arglist);
  my ($count)=1;

  ($mainmsg,$replacearg_list)=split(/#/, $msgtext);
  (@arglist)=split(/,/, $replacearg_list);

  foreach my $rstr (@arglist)
    {
        my $fholder="FIELD_";
	if ($count < 10) {
	  $fholder .= $count; }
	else
	  { $fholder .= "_$count"; }

        $mainmsg =~ s/$fholder/$rstr/g;
        $count++;
    } # end foreach loop

  # special case after processing
  $mainmsg =~ s/XX/##/g;
  $mainmsg =~ s/NL/\n/g;
  $mainmsg =~ s/TB/\t/g;
  $mainmsg =~ s/__/,/g;

  return($mainmsg);
} # end sub


sub prog_usage
{ # start sub
  my ($SCR_NAME, $REQHASH, $OPTHASH) = @_;
  my ($required)=" ";
  my ($tagid);

  print <<EOF;
#############################################################################
##
## ERROR: $REQHASH->{'ERR'}
##
## Usage:
##    $SCR_NAME
EOF
   foreach $tagid (sort keys (%$REQHASH))
     {
        next if ($tagid =~ /ERR/i);
        print "##\t-$tagid\t" . $REQHASH->{$tagid} . "\n";
        $required .= "-" . $tagid . " ";
     }

   print <<EOF;
##
## Required params: $required
## Optional params:
EOF

   foreach $tagid (sort keys (%$OPTHASH))
     {
        print "##\t-" . $tagid . "\t" . $OPTHASH->{$tagid} . "\n";
     }

   print <<EOF;
##
#############################################################################

EOF
   exit(0);
} # end sub


sub moveFile
{
  my ($sourceD,                 # source directory of the file
      $filename,                # filename to be moved
      $destD) = @_;             # destination directory

   my (@args) = ("mv","$sourceD/$filename", "$destD");
   system(@args);
} # end sub


sub determineLayout
{
   my ($FL_name,                        # the file name passed in
        $cfgHash) = @_;                 # the  configuration hash
   my ($whatLayout);                    # type of layout to use
   my ($junk,                           # first field
       $fltype,                         # the type of file
       @junk);                          # remaining file details
   my ($fullName);                      # the full path of input file
   my ($ERROR)=0;                       # set error to zero

   $fullName = $cfgHash->{'SCANDIR'} . "/" . $FL_name;
   ($junk, $fltype, @junk) = split(/_/, $FL_name);
   if ($fltype =~ /elig/i)      # check for elig in the name
     {
        $whatLayout="ELIGIBILITY";
     }
   elsif ($fltype =~ /medi/i)  # check for medi in the name
     {
        $whatLayout = "MEDCLAIMS";
     }
   elsif ($fltype =~ /phar/i)  # check for phar in the name
     {
        $whatLayout = "PHARMA";
     }
   elsif ($fltype =~ /lab/i)   # check for lab in the name
     {
        $whatLayout = "LABCLM";
     }
   elsif ($fltype =~ /prov/i)  # check for prov in the name
     {
        $whatLayout = "PROVIDER";
     }
   else
     { # file name was not standard - analyze further
        # file name didn't meet the standard of containing
        # elig|medi|phar|lab|prov in the name
        my ($firstLine,                 # first line of input file
            $firstChar,                 # get first character of the header
            $charCount);                # length of the line

        $firstLine = `head -1 $fullName`;
        chomp($firstLine);
        $charCount = length($firstLine);
        $firstChar = substr($firstLine, 0, 1);

        # if logic to select the correct layout file
        if ($charCount == $cfgHash->{'ELIG_HDRSZ'})
          { # check first character
            if ($firstChar == 1)
              {
                $whatLayout = "ELIGIBILITY";
              }
            else
              { # bad first character
                $ERROR=-1;      # set a flag on error
              }
          }
        elsif ($charCount == $cfgHash->{'MPL_HDRSZ'})
          { # check subtype (ie: medical/pharmacy/lab)
            if ($firstChar == 3)
              {
                $whatLayout = "MEDCLAIMS";
              }
            elsif ($firstChar == 5)
              {
                $whatLayout = "PHARMA";
              }
            elsif ($firstChar = 7)
              {
                $whatLayout = "LABCLM";
              }
            else
              { # bad first char
                $ERROR = -1;    # set error flag
              }
          }
        elsif ($charCount == $cfgHash->{'PROV_HDRSZ'})
          { # check first character
            if ($firstChar == 9)
              {
                $whatLayout = "PROVIDER";
              }
            else
              { # bad first character
                $ERROR=-1;      # set error flag
              }
          } # check first char
     } # file name is not standard

  $whatLayout = "UNKNOWN" if ($ERROR == -1);

  return($whatLayout);   # return the final layout type
} #end sub


sub getCustomer
{
   my ($FL_name) = @_;
   my ($custname,               # the customer name
       @stuff);                 # remaing file details

   ($custname, @stuff) = split(/_/, $FL_name);
   return($custname);
} # end function

1;
